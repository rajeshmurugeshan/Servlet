package org.firstServletAssing.UiApp;

import java.io.*;
import javax.servlet.*;

public class FirstServletAssign extends GenericServlet  {

	@Override
	public void service(ServletRequest req, ServletResponse resp) throws ServletException, IOException {
		String firstName=req.getParameter("fnm");
		String lastName=req.getParameter("lnm");
		
		PrintWriter out=resp.getWriter();
		out.println("<html><body bgcolor='cyan'>"+ "<h1> Hii "+firstName+" "+lastName+"</h1>"+"</body></html>");
		out.flush();
		out.close();
		
		
	}

}
